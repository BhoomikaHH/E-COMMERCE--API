import { Product, CartItem } from '../types';

const API_BASE_URL = 'http://localhost:4000/api';

const getAuthToken = (): string | null => {
  try {
    const token = localStorage.getItem('authToken');
    return token;
  } catch (error) {
    console.error("Could not retrieve auth token from localStorage", error);
    return null;
  }
}

const apiFetch = async (endpoint: string, options: RequestInit = {}) => {
  const token = getAuthToken();
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers,
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ message: 'An unknown error occurred' }));
    throw new Error(errorData.message || 'API request failed');
  }
  return response.json();
};

class ApiService {
  async getProducts(search: string = ''): Promise<Product[]> {
    const query = search ? `?search=${encodeURIComponent(search)}` : '';
    return apiFetch(`/products${query}`);
  }

  async addProduct(productData: Omit<Product, 'id'>): Promise<Product> {
    return apiFetch('/products', {
      method: 'POST',
      body: JSON.stringify(productData),
    });
  }

  async updateProduct(productId: string, productData: Partial<Product>): Promise<Product> {
    return apiFetch(`/products/${productId}`, {
      method: 'PUT',
      body: JSON.stringify(productData),
    });
  }

  async deleteProduct(productId: string): Promise<{ success: boolean }> {
     return apiFetch(`/products/${productId}`, { method: 'DELETE' });
  }
  
  async placeOrder(items: CartItem[]): Promise<{ success: boolean; orderId: string }> {
    return apiFetch('/orders', {
        method: 'POST',
        body: JSON.stringify({ items }),
    });
  }
}

export const apiService = new ApiService();
