import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { apiService } from '../../services/api';
import { Product, Role } from '../../types';
import { ProductCard } from '../ProductCard';
import { useAuth } from '../../hooks/useAuth';
import { Modal } from '../common/Modal';
import { ProductForm } from '../ProductForm';
import { Button } from '../common/Button';

const ITEMS_PER_PAGE = 6;

const PlusIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
    </svg>
);

export const ProductListView: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [productToEdit, setProductToEdit] = useState<Product | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const { user } = useAuth();

    const fetchProducts = useCallback(async () => {
        try {
            // This function is now used for refreshing the list after mutations
            const data = await apiService.getProducts(searchQuery);
            setProducts(data);
            setError(null);
        } catch (err) {
            setError('Failed to fetch products.');
            console.error(err);
        }
    }, [searchQuery]);
    
    useEffect(() => {
        const getProductsFromServer = async () => {
             try {
                setIsLoading(true);
                const data = await apiService.getProducts(searchQuery);
                setProducts(data);
                setError(null);
            } catch (err) {
                const errorMessage = err instanceof Error ? err.message : 'Failed to fetch products.';
                setError(errorMessage);
                console.error(err);
            } finally {
                setIsLoading(false);
            }
        };
        // Debounce fetching to avoid API calls on every keystroke
        const handler = setTimeout(() => {
            getProductsFromServer();
        }, 300); // 300ms delay

        return () => {
            clearTimeout(handler);
        };
    }, [searchQuery]);

    const handleOpenModalForCreate = () => {
        setProductToEdit(null);
        setIsModalOpen(true);
    };

    const handleOpenModalForEdit = (product: Product) => {
        setProductToEdit(product);
        setIsModalOpen(true);
    };

    const handleSaveProduct = async (productData: Omit<Product, 'id'> | Product) => {
        setIsSubmitting(true);
        try {
            if ('id' in productData && productData.id) {
                await apiService.updateProduct(productData.id, productData);
            } else {
                await apiService.addProduct(productData);
            }
            await fetchProducts(); // Re-fetch the list
            setIsModalOpen(false);
        } catch (err) {
            console.error("Failed to save product", err);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteProduct = async (productId: string) => {
        if(window.confirm('Are you sure you want to delete this product?')) {
            try {
                await apiService.deleteProduct(productId);
                await fetchProducts(); // Re-fetch the list
            } catch (err) {
                console.error("Failed to delete product", err);
            }
        }
    };

    // Pagination is now done on the client side from the server's filtered results
    const paginatedProducts = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return products.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [products, currentPage]);

    const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);

    if (isLoading && products.length === 0) return <div className="text-center p-10">Loading products...</div>;
    if (error) return <div className="text-center p-10 text-red-500">{error}</div>;

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                <h1 className="text-3xl font-bold text-gray-800">Explore Our Products</h1>
                <div className="flex items-center gap-4 w-full md:w-auto">
                   <input
                        type="text"
                        placeholder="Search by name or category..."
                        value={searchQuery}
                        onChange={e => {
                            setSearchQuery(e.target.value);
                            setCurrentPage(1); // Reset to first page on new search
                        }}
                        className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    {user?.role === Role.ADMIN && (
                        <Button onClick={handleOpenModalForCreate}>
                           <PlusIcon/> Add Product
                        </Button>
                    )}
                </div>
            </div>
            
            {products.length > 0 ? (
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                    {paginatedProducts.map(product => (
                        <ProductCard key={product.id} product={product} onEdit={handleOpenModalForEdit} onDelete={handleDeleteProduct} />
                    ))}
                </div>
            ) : (
                !isLoading && <div className="text-center p-10 text-gray-500">No products found.</div>
            )}

            {totalPages > 1 && (
                <div className="flex justify-center items-center mt-12 space-x-2">
                    <Button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</Button>
                    <span className="text-gray-700">Page {currentPage} of {totalPages}</span>
                    <Button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</Button>
                </div>
            )}

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title={productToEdit ? 'Edit Product' : 'Add New Product'}>
                <ProductForm 
                    productToEdit={productToEdit} 
                    onSave={handleSaveProduct}
                    onCancel={() => setIsModalOpen(false)}
                    isLoading={isSubmitting}
                />
            </Modal>
        </div>
    );
};