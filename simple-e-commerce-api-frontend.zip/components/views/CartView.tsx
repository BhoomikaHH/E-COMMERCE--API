import React, { useState } from 'react';
import { useCart } from '../../hooks/useCart';
import { Button } from '../common/Button';
import { View } from '../../types';
import { apiService } from '../../services/api';

const TrashIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

export const CartView: React.FC<{ setView: (view: View) => void }> = ({ setView }) => {
    const { cartItems, updateQuantity, removeFromCart, clearCart, totalPrice } = useCart();
    const [isOrderPlaced, setIsOrderPlaced] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handlePlaceOrder = async () => {
        setIsSubmitting(true);
        setError(null);
        try {
            await apiService.placeOrder(cartItems);
            clearCart();
            setIsOrderPlaced(true);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred. Please try again.';
            setError(errorMessage);
            console.error(err);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isOrderPlaced) {
        return (
            <div className="text-center p-10 max-w-2xl mx-auto bg-white mt-10 rounded-lg shadow-md">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h2 className="text-3xl font-bold text-gray-800 mt-4">Thank You!</h2>
                <p className="text-gray-600 mt-2">Your order has been placed successfully.</p>
                <Button onClick={() => setView('products')} className="mt-6">Continue Shopping</Button>
            </div>
        );
    }

    if (cartItems.length === 0) {
        return (
            <div className="text-center p-10 max-w-2xl mx-auto bg-white mt-10 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold text-gray-800">Your Cart is Empty</h2>
                <p className="text-gray-600 mt-2">Looks like you haven't added anything to your cart yet.</p>
                <Button onClick={() => setView('products')} className="mt-6">Start Shopping</Button>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-3xl font-bold text-gray-800 mb-8">Your Shopping Cart</h1>
            {error && <div className="bg-red-100 text-red-700 p-3 rounded-md mb-4">{error}</div>}
            <div className="bg-white rounded-lg shadow-md">
                <ul className="divide-y divide-gray-200">
                    {cartItems.map(item => (
                        <li key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row items-center justify-between">
                            <div className="flex items-center mb-4 sm:mb-0">
                                <img src={item.imageUrl} alt={item.name} className="h-20 w-20 rounded-md object-cover mr-4" />
                                <div>
                                    <h3 className="font-semibold text-gray-800">{item.name}</h3>
                                    <p className="text-sm text-gray-500">${item.price.toFixed(2)}</p>
                                </div>
                            </div>
                            <div className="flex items-center space-x-4">
                                <div className="flex items-center border border-gray-300 rounded-md">
                                    <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="px-3 py-1 text-lg font-bold text-gray-600 hover:bg-gray-100">-</button>
                                    <span className="px-4 py-1">{item.quantity}</span>
                                    <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="px-3 py-1 text-lg font-bold text-gray-600 hover:bg-gray-100">+</button>
                                </div>
                                <p className="font-semibold w-24 text-right">${(item.price * item.quantity).toFixed(2)}</p>
                                <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500">
                                    <TrashIcon />
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
                <div className="p-6 bg-gray-50 rounded-b-lg flex flex-col sm:flex-row items-center justify-between">
                    <div className="text-2xl font-bold text-gray-800 mb-4 sm:mb-0">
                        Total: <span className="text-indigo-600">${totalPrice.toFixed(2)}</span>
                    </div>
                    <Button onClick={handlePlaceOrder} size="lg" disabled={isSubmitting}>
                        {isSubmitting ? 'Placing Order...' : 'Place Order'}
                    </Button>
                </div>
            </div>
        </div>
    );
};