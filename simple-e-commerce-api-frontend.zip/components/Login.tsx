
import React from 'react';
import { useAuth } from '../hooks/useAuth';
import { Role, View } from '../types';
import { Button } from './common/Button';

interface LoginProps {
  setView: (view: View) => void;
}

export const Login: React.FC<LoginProps> = ({ setView }) => {
  const { login } = useAuth();

  const handleLogin = (role: Role) => {
    login(role);
    setView('products');
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-8 bg-white rounded-xl shadow-lg">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800">Welcome Back!</h2>
        <p className="mt-2 text-gray-600">Choose your role to continue.</p>
      </div>
      <div className="mt-8 space-y-4">
        <Button 
          onClick={() => handleLogin(Role.CUSTOMER)} 
          className="w-full text-lg py-3"
        >
          Login as Customer
        </Button>
        <Button 
          variant="secondary" 
          onClick={() => handleLogin(Role.ADMIN)} 
          className="w-full text-lg py-3"
        >
          Login as Admin
        </Button>
      </div>
    </div>
  );
};
