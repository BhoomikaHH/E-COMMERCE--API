# Simple E-commerce Full-Stack Project

This is a full-stack e-commerce application featuring a React frontend and a Node.js/Express backend.

## Project Structure

- **`/` (Root)**: Contains the frontend React application.
- **`/backend`**: Contains the Node.js, Express, and TypeScript backend server.

## How to Run

This project requires [Node.js](https://nodejs.org/) and npm to be installed.

### 1. Install Dependencies

First, install the necessary dependencies for both the frontend and the backend.

Navigate to the project's root directory in your terminal and run:

```bash
npm install
```

This command will install the React dependencies for the frontend and also install the backend dependencies by running the `postinstall` script which executes `npm install` inside the `/backend` directory.

### 2. Start Both Servers

To run both the frontend and backend servers at the same time, use the `start` script from the root directory:

```bash
npm start
```

This will concurrently run:
- The **frontend server** (using a simple static server) on `http://localhost:8080`
- The **backend API server** on `http://localhost:4000`

You can now open your browser and navigate to **http://localhost:8080** to use the application.
