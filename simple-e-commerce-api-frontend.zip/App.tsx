
import React, { useState } from 'react';
import { Header } from './components/Header';
import { useAuth } from './hooks/useAuth';
import { ProductListView } from './components/views/ProductListView';
import { CartView } from './components/views/CartView';
import { Login } from './components/Login';
import { View, Role } from './types';

const App: React.FC = () => {
    const [view, setView] = useState<View>('products');
    const { user, isLoading } = useAuth();

    const renderView = () => {
        if (isLoading) {
            return <div className="text-center p-10">Loading...</div>;
        }

        if (view === 'login' && !user) {
            return <Login setView={setView} />;
        }
        
        switch (view) {
            case 'cart':
                return <CartView setView={setView} />;
            case 'admin':
                // Only allow admins to see the admin view, otherwise redirect
                if (user?.role === Role.ADMIN) {
                    return <ProductListView />; // Admin controls are inside ProductListView
                }
                // Fallthrough to products view if not admin
            case 'products':
            default:
                return <ProductListView />;
        }
    };
    
    return (
        <div className="min-h-screen bg-gray-50">
            <Header setView={setView} />
            <main>
                {renderView()}
            </main>
        </div>
    );
};

export default App;
