import React, { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { User, Role } from '../types';

const API_BASE_URL = 'http://localhost:4000/api';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (role: Role) => Promise<void>;
  logout: () => void;
}

// A simple JWT decoder
const decodeToken = (token: string): User | null => {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return {
      id: payload.id,
      name: payload.name,
      role: payload.role,
    };
  } catch (e) {
    console.error("Failed to decode token", e);
    return null;
  }
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const storedToken = localStorage.getItem('authToken');
      if (storedToken) {
        setToken(storedToken);
        const decodedUser = decodeToken(storedToken);
        setUser(decodedUser);
      }
    } catch (error) {
      console.error("Failed to parse auth data from localStorage", error);
      localStorage.removeItem('authToken');
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(async (role: Role) => {
    try {
      const response = await fetch(`${API_BASE_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role }),
      });
      if (!response.ok) {
        throw new Error('Login failed');
      }
      const { token } = await response.json();

      localStorage.setItem('authToken', token);
      const decodedUser = decodeToken(token);
      setToken(token);
      setUser(decodedUser);
    } catch (error) {
      console.error("Login request failed", error);
    }
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('authToken');
    setToken(null);
    setUser(null);
  }, []);

  const value = { user, token, isLoading, login, logout };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
