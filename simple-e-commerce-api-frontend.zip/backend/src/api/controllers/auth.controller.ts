import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../../config';
import { Role, User } from '../../types';

export const login = (req: Request, res: Response) => {
    const { role } = req.body;

    if (!role || (role !== Role.CUSTOMER && role !== Role.ADMIN)) {
        return res.status(400).json({ message: 'Invalid role specified' });
    }

    const user: User = {
        id: `user-${Date.now()}`,
        name: role === Role.ADMIN ? 'Admin User' : 'Valued Customer',
        role: role,
    };

    const token = jwt.sign(
        { id: user.id, name: user.name, role: user.role },
        config.jwtSecret,
        { expiresIn: '24h' }
    );

    res.status(200).json({ token });
};