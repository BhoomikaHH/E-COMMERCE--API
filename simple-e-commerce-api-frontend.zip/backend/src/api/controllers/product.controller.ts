import { Request, Response } from 'express';
import { products } from '../../data';
import { Product } from '../../types';

// GET /api/products
export const getProducts = (req: Request, res: Response) => {
    const searchQuery = (req.query.search as string || '').toLowerCase();
    
    if (searchQuery) {
        const filteredProducts = products.filter(p => 
            p.name.toLowerCase().includes(searchQuery) || 
            p.category.toLowerCase().includes(searchQuery)
        );
        return res.json(filteredProducts);
    }
    
    res.json(products);
};

// POST /api/products
export const createProduct = (req: Request, res: Response) => {
    const { name, price, description, category, imageUrl } = req.body;
    if (!name || !price || !description || !category) {
        return res.status(400).json({ message: 'Missing required product fields' });
    }

    const newProduct: Product = {
        id: new Date().getTime().toString(),
        name,
        price: parseFloat(price),
        description,
        category,
        imageUrl: imageUrl || `https://picsum.photos/seed/${Date.now()}/400/300`,
    };
    
    products.unshift(newProduct);
    res.status(201).json(newProduct);
};

// PUT /api/products/:id
export const updateProduct = (req: Request, res: Response) => {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id === id);

    if (productIndex === -1) {
        return res.status(404).json({ message: 'Product not found' });
    }

    const updatedProduct = { ...products[productIndex], ...req.body };
    products[productIndex] = updatedProduct;

    res.json(updatedProduct);
};

// DELETE /api/products/:id
export const deleteProduct = (req: Request, res: Response) => {
    const { id } = req.params;
    const productIndex = products.findIndex(p => p.id === id);
    
    if (productIndex === -1) {
        return res.status(404).json({ message: 'Product not found' });
    }

    products.splice(productIndex, 1);

    res.json({ success: true });
};