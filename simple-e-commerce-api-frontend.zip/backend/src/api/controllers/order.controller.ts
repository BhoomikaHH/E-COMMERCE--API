import { Request, Response } from 'express';
import { orders, products as allProducts } from '../../data';
import { CartItem, Order, Product } from '../../types';

// POST /api/orders
export const createOrder = (req: Request, res: Response) => {
    const { items } = req.body as { items: CartItem[] };
    const user = req.user;

    if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ message: 'Cart items are required and must be a non-empty array.' });
    }

    let totalPrice = 0;
    const validatedOrderItems: CartItem[] = [];

    // Server-side validation of cart items and prices
    for (const item of items) {
        if (!item || typeof item.id !== 'string' || typeof item.quantity !== 'number' || !Number.isInteger(item.quantity) || item.quantity <= 0) {
            return res.status(400).json({ message: 'Invalid item in cart. Each item must have a valid product ID and a positive integer quantity.' });
        }

        const product: Product | undefined = allProducts.find(p => p.id === item.id);
        if (!product) {
            return res.status(400).json({ message: `Invalid product in cart: Product with ID ${item.id} not found.` });
        }

        totalPrice += product.price * item.quantity;
        
        validatedOrderItems.push({
            ...product,
            quantity: item.quantity,
        });
    }
    
    const newOrder: Order = {
        orderId: `order-${Date.now()}`,
        userId: user.id,
        items: validatedOrderItems, // Use server-validated item details
        totalPrice,
        orderDate: new Date(),
    };

    orders.push(newOrder);

    console.log(`New order placed: ${newOrder.orderId} by user ${user.id} with total $${totalPrice.toFixed(2)}`);

    res.status(201).json({ success: true, orderId: newOrder.orderId });
};