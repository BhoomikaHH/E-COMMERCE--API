import { Product, Order } from './types';

export const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Quantum Leap Laptop',
    price: 1299.99,
    description: 'The next generation of portable computing. Blazing fast and ultra-light.',
    category: 'Electronics',
    imageUrl: 'https://picsum.photos/seed/laptop/400/300',
  },
  {
    id: '2',
    name: 'Stellar Sound Headphones',
    price: 199.99,
    description: 'Noise-cancelling headphones with studio-quality audio.',
    category: 'Audio',
    imageUrl: 'https://picsum.photos/seed/headphones/400/300',
  },
  {
    id: '3',
    name: 'Ergo-Mechanical Keyboard',
    price: 149.50,
    description: 'A comfortable and responsive keyboard for coders and writers.',
    category: 'Peripherals',
    imageUrl: 'https://picsum.photos/seed/keyboard/400/300',
  },
  {
    id: '4',
    name: '4K Ultra-Wide Monitor',
    price: 799.00,
    description: 'Immerse yourself in stunning detail with this curved 34-inch monitor.',
    category: 'Displays',
    imageUrl: 'https://picsum.photos/seed/monitor/400/300',
  },
  {
    id: '5',
    name: 'Smart Fitness Watch',
    price: 249.99,
    description: 'Track your health and stay connected on the go.',
    category: 'Wearables',
    imageUrl: 'https://picsum.photos/seed/watch/400/300',
  },
  {
    id: '6',
    name: 'Pro Gaming Mouse',
    price: 89.99,
    description: 'High-precision gaming mouse with customizable RGB lighting.',
    category: 'Peripherals',
    imageUrl: 'https://picsum.photos/seed/mouse/400/300',
  },
  {
    id: '7',
    name: 'Portable SSD 1TB',
    price: 159.99,
    description: 'Fast and reliable external storage for all your files.',
    category: 'Storage',
    imageUrl: 'https://picsum.photos/seed/ssd/400/300',
  },
  {
    id: '8',
    name: 'HD Webcam',
    price: 69.99,
    description: 'Crystal clear video for your online meetings and streams.',
    category: 'Peripherals',
    imageUrl: 'https://picsum.photos/seed/webcam/400/300',
  },
];

// In-memory "database"
export let products: Product[] = [...initialProducts];
export let orders: Order[] = [];
