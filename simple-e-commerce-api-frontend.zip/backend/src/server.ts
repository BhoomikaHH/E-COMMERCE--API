import express, { Request, Response } from 'express';
import cors from 'cors';
import authRoutes from './api/routes/auth.routes';
import productRoutes from './api/routes/product.routes';
import orderRoutes from './api/routes/order.routes';

const app = express();
const PORT = 4000;

// Middleware
const corsOptions = {
    origin: 'http://localhost:8080', // Allow only the frontend to access the API
    optionsSuccessStatus: 200 
};
app.use(cors(corsOptions));
app.use(express.json());

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);

app.get('/', (req: Request, res: Response) => {
    res.send('E-commerce Backend is running!');
});

app.listen(PORT, () => {
    console.log(`Backend server is running on http://localhost:${PORT}`);
});