export const config = {
    jwtSecret: 'your-super-secret-and-long-jwt-secret-key-12345'
};
